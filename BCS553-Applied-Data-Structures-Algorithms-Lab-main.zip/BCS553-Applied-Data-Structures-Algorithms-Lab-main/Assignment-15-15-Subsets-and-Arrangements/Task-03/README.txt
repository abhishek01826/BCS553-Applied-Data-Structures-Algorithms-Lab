Assignment 15, Task 3
Compile: javac Main.java
Run: java Main
See output.txt for expected output.
