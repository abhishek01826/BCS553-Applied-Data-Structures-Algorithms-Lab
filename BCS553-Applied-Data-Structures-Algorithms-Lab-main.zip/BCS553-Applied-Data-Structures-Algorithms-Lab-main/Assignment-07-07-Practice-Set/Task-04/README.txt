Assignment 7, Task 4
Compile: javac Main.java
Run: java Main
See output.txt for expected output.
