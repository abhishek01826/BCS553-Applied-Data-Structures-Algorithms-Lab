Assignment 3, Task 1
Compile: javac Main.java
Run: java Main
See output.txt for expected output.
